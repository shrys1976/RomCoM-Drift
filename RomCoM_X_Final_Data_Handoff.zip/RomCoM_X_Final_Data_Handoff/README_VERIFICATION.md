# RomCoM-X final data handoff (verification package)

## Status
See `reports/final_data_handoff_report.md` and top-level `final_data_handoff_report.md`.

## Row-level provenance
- `manifests/example_provenance.csv` — one row per processed example (IDs, source revision, hashes).
- `manifests/source_split_manifest.csv` — split assignment and grouping metadata.
- `manifests/data_provenance.csv` — source-dataset level pins (revisions, licenses).

## Processed datasets (required)
`processed/EXP-01_canonical|EXP-02_realistic|EXP-03_matched_noise/{train,validation}.jsonl`

Counts (EXP-01): train 57606, validation 12870. All three conditions share identical `example_id` sets.

## Code-mixed base (pre romanization EXP)
`intermediate/{nli,paraphrase,toxicity}_base.jsonl` — reconstructed Indi-RomCoM methodology, not official release.

## Traces
`traces/EXP-0{1,2,3}/traces.jsonl` — token-level augmentation records (also in traces supplement zip if split).

## Excluded intentionally
- Raw COMI-LINGUA JSONL and full IndicXNLI train JSON (local-only; restore via repo `scripts/download_raw_datasets.py`).
- Secrets / model checkpoints.

## Reproduce locally
```bash
PYTHONPATH=src uv run python -m romcom_data
```
